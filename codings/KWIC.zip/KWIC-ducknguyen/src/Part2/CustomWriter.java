package Part2;

/**
 * @author Duck Nguyen
 * @date June 12th, 2018
 *
 * CustomWriter accepts a file destination and a shifted ArrayList,
 * scan through the ArrayList and output to destination file and console
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CustomWriter
{
    private FileWriter toWrite;
    private BufferedWriter writer;
    private ArrayList<String> outputLines;

    public CustomWriter()
    {
        outputLines = new ArrayList<>();
    }

    protected void writeToFileAndConsole(String destination, ArrayList<String> toProcess) throws IOException
    {
        toWrite = new FileWriter(destination);
        writer = new BufferedWriter(toWrite);
        outputLines = toProcess;

        toWrite = new FileWriter(destination);
        writer = new BufferedWriter(toWrite);

        System.out.println("=============== OUTPUT TEXT FOR PART #2 =============== \n");

        for (String line : outputLines)
        {
            writer.write(line);
            writer.newLine();
            System.out.println(line);
        }

        writer.close();
        toWrite.close();
    }
}
