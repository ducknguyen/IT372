package Part2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.StringJoiner;

/**
 * @author Duck Nguyen
 * @date June 12th, 2018
 *
 * CircularlyShifter accepts an arraylist to process,
 * scan through its contents and perform circular shift,
 * and store a shiftedLines arraylist resulted from above shifting.
 */

public class CircularlyShifter
{
    ArrayList<String> shiftedLines;

    public CircularlyShifter()
    {
        shiftedLines = new ArrayList<>();
    }

    protected ArrayList<String> circularlyShift(ArrayList<String> toShift)
    {
        for (String line : toShift)
        {
            String first = "";
            String[] words = line.split(" ");
            StringJoiner shiftedLine = new StringJoiner(" ");

            if(words.length > 1)
            {
                first = words[0];
                for (int i = 0; i < words.length; i++){
                    shiftedLine.add(words[i]);
                }
            }
            shiftedLine.add(first);
            shiftedLines.add(shiftedLine.toString());
        }

        Collections.sort(shiftedLines);
        return shiftedLines;
    }
}
