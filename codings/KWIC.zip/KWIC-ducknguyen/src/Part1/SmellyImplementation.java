package Part1;


import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringJoiner;

/**
 * @author Duck Nguyen
 * @date June 12th, 2018
 *
 * SmellyImplementation is a bad implementation of KWIC where all
 * codes are condensed into the main method
 */
public class SmellyImplementation
{
    private static ArrayList<String> storedLines = new ArrayList<>();
    private static ArrayList<String> outputLines = new ArrayList<>();


    public static void main(String[] args)
    {
        String file = "files/warAndpeace.txt";
        String outputFile = "out/warAndpeaceOutput";


        try
        {
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

        // READ AND STORE ALL LINES FROM TXT FILE
            String currentLine;
            while((currentLine = bufferedReader.readLine()) != null)
            {
                if (currentLine.length() > 1)
                {
                    storedLines.add(currentLine);
                }
            }

        // CIRCULARLY SHIFT AND ADD TO OUTPUTLINE
            for (String line : storedLines)
            {
                String first = "";
                String[] words = line.split(" ");
                StringJoiner shiftedLine = new StringJoiner(" ");

                if(words.length > 1)
                {
                    first = words[0];
                    for (int i = 0; i < words.length; i++){
                        shiftedLine.add(words[i]);
                    }
                }
                shiftedLine.add(first);
                outputLines.add(shiftedLine.toString());
                storedLines = outputLines;
            }

        // SORT OUTPUTLINE ALPHABETICALLY
            Collections.sort(storedLines);


        // PRINT OUT TO NEW TEXT FILE AND PRINT TO CONSOLE
            FileWriter fileWriter = new FileWriter(outputFile);
            BufferedWriter writer = new BufferedWriter(fileWriter);

            System.out.println("=============== OUTPUT TEXT =============== \n");

            for (String line : storedLines)
            {
                writer.write(line);
                writer.newLine();
                System.out.println(line);
            }

            bufferedReader.close();
            fileReader.close();

            writer.close();
            fileWriter.close();

        } catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
