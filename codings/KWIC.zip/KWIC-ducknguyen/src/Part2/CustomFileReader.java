package Part2;

/**
 * @author Duck Nguyen
 * @date June 12th, 2018
 *
 * CustomFileReader accepts a file, read through it line by line,
 * and maintain a list of StoredLines from said file.
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CustomFileReader
{
    private FileReader toRead;
    private BufferedReader reader;
    private ArrayList<String> storedLines;

    public CustomFileReader()
    {
        storedLines = new ArrayList<>();
    }

    protected ArrayList<String> readFromFile(String destination) throws IOException
    {
        toRead = new FileReader(destination);
        reader = new BufferedReader(toRead);

        String currentLine;
        while((currentLine = reader.readLine()) != null)
        {
            if (currentLine.length() > 1)
            {
                storedLines.add(currentLine);
            }
        }

        reader.close();
        toRead.close();

        return storedLines;
    }
}
