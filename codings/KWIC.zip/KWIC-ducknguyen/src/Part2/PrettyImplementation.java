package Part2;

import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Duck Nguyen
 * @date June 12th, 2018
 *
 * PrettyImplementation is a pretty implementation of KWIC where all
 * codes/functionalities are separated into different objects
 */
public class PrettyImplementation
{
    public static void main(String[] args) throws IOException
    {
        String destination = "files/warAndpeace.txt";
        String outputFile = "out/warAndpeaceOutput_PT2";

        CustomFileReader myReader = new CustomFileReader();
        ArrayList<String> storedLines = myReader.readFromFile(destination);

        CircularlyShifter myShifter = new CircularlyShifter();
        ArrayList<String> shiftedLines = myShifter.circularlyShift(storedLines);

        CustomWriter myWriter = new CustomWriter();
        myWriter.writeToFileAndConsole(outputFile, shiftedLines);
    }
}
