package test;

import junit.framework.TestCase;
import main.StringSorter;

import java.util.ArrayList;
import java.io.*;
import java.util.Collection;
import java.util.Collections;

public class TestStringSorter extends TestCase {

	private ArrayList make123() {
		ArrayList l = new ArrayList();
		l.add("one");
		l.add("two");
		l.add("three");

		return l;
	}

	private ArrayList makeDuplciate() {
		ArrayList l = new ArrayList();
		l.add("one");
		l.add("two");
		l.add("three");
		l.add("two");

		return l;
	}

	public void testFindIdxBiggest() {
		StringSorter ss=new StringSorter();

		ArrayList l = make123();
		int i=StringSorter.findIdxBiggest(l,0,l.size()-1);
		assertEquals(i,1);

		// test if findIdxBiggest will return the first biggest index
		// in a list with multiple duplicate biggest
		ArrayList l2 = makeDuplciate();
		int i2 = StringSorter.findIdxBiggest(l2, 0, l2.size()-1);
		assertEquals(i2, 1);
	}

	public void testSwap() {
		ArrayList l1= make123();

		ArrayList l2=new ArrayList();
		l2.add("one");
		l2.add("three");
		l2.add("two");

		StringSorter.swap(l1,1,2);
		assertEquals(l1,l2);

		// test for swapping a list with only one element
		// should replace itself and thus does not change value
		ArrayList l3 = new ArrayList();
		l3.add("one");

		StringSorter.swap(l3, 0, l3.size()-1);
		assertEquals(l3.get(0), l3.get(l3.size()-1));
		assertEquals(l3.get(0), "one");
	}

	public void testReadFromStream() throws IOException{
		Reader in=new FileReader("files/in/in.txt");
		StringSorter ss=new StringSorter();
		ArrayList l= make123();

		ss.readFromStream(in);
		assertEquals(l,ss.lines);

		// test case for reading from an empty file
		// StringSorter internal array size should be empty
		ss=new StringSorter();
		in = new FileReader("files/in/empty.txt");
		ss.readFromStream(in);
		assertEquals(ss.lines.size(),0);
	}

	public void testSort1() {
		StringSorter ss= new StringSorter();
		ss.lines=make123();

		ArrayList l2=new ArrayList();
		l2.add("one");
		l2.add("three");
		l2.add("two");

		ss.sort();
		assertEquals(l2,ss.lines);

		//test case for sorting list with duplicates
		ss.lines = makeDuplciate();

		ArrayList l3 = new ArrayList();
		l3.add("one");
		l3.add("three");
		l3.add("two");
		l3.add("two");

		ss.sort();
		assertEquals(l3,ss.lines);
	}

	public void testWriteToStream() throws IOException{
		// write out a known value
		StringSorter ss1=new StringSorter();
		ss1.lines=make123();
		Writer out=new FileWriter("files/out/test.out");
		ss1.writeToStream(out);
		out.close();

		// then read it and compare
		Reader in=new FileReader("files/in/in.txt");
		StringSorter ss2=new StringSorter();
		ss2.readFromStream(in);
		assertEquals(ss1.lines,ss2.lines);

		// test case for reading from empty file
		// see if we are able to write to a new file from there
		StringSorter ss3 = new StringSorter();

		ss3.readFromStream(new FileReader("files/in/empty.txt"));
		ss3.writeToStream(new FileWriter("files/out/empty-out.out"));
		ss3.readFromStream(new FileReader("files/out/empty-out.out"));

		assertEquals(ss3.lines.size(),0);
	}

	public void testSort2() throws IOException{
		// write out a known value
		StringSorter ss1=new StringSorter();
		ss1.sort("files/in/in.txt","files/out/test2.out");

		ArrayList l=new ArrayList();
		l.add("one");
		l.add("three");
		l.add("two");

		// then read it and compare
		Reader in=new FileReader("files/out/test2.out");
		StringSorter ss2=new StringSorter();
		ss2.readFromStream(in);
		assertEquals(l,ss2.lines);


		// test case for sorting a list with duplicate
		// then write to a file
		StringSorter ss3 = new StringSorter();
		ss3.sort("files/in/in2.txt", "files/out/test3.out");

		ArrayList l2 = makeDuplciate();
		Collections.sort(l2);
		
		StringSorter ss4 = new StringSorter();
		ss4.readFromStream(new FileReader("files/out/test3.out"));
		assertEquals(l2, ss4.lines);
	}

}
