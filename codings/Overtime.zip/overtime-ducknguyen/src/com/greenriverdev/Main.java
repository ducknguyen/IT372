package com.greenriverdev;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class Main {

    private static final int PAY_RATE = 10;
    private static final int DAILY_MAX_HOURS = 8;
    private static final int WEEKLY_MAX_HOURS = 40;

    public static void main(String[] args) throws IOException {

        // prompt user
        Scanner stdin = new Scanner(System.in);
        System.out.print("Filename: ");
        String name = stdin.nextLine();

        // grabs file and start reading
        File file = new File(name);
        Scanner fileIn = new Scanner(file);
        int rows = fileIn.nextInt();
        fileIn.nextLine();

        // reading file
        for (int i = 0; i < rows; i++) {
            String line = fileIn.nextLine();
            System.out.println(line);
            Scanner lineIn = new Scanner(line);

            int[] timesheet = new int[7];   // 7 days in the week
            int totalBonusHours = 0;
            int totalWeekHours = 0;
            int initialPay = 0;

            for (int j = 0; j < 7; j++) {

                timesheet[j] = lineIn.nextInt();
                totalWeekHours += timesheet[j];
                initialPay += calcInitialPay(j, timesheet[j]);

                if (timesheet[j] > DAILY_MAX_HOURS)   totalBonusHours+= (timesheet[j]-DAILY_MAX_HOURS);

                System.out.println(initialPay + " -- " + timesheet[j] + " -- " + totalWeekHours + " -- " + totalBonusHours);
            }

            System.out.println("After loop ->" + initialPay + " -- " + totalWeekHours + " -- " + totalBonusHours);

            int bonusPay = calcBonusPay(totalBonusHours, totalWeekHours);
            int totalPay = initialPay + bonusPay;

            System.out.println("Total pay is: " + totalPay);
        }
    }

    // helper method for calculating initial pay without bonus
    private static int calcInitialPay(int day, int hours)
    {
        int initialPay = 0;

        if (day == 0)       initialPay = (int) (PAY_RATE * 1.5 * hours);
        else if (day == 6)  initialPay = PAY_RATE * 2 * hours;
        else                initialPay = PAY_RATE * hours;

        return initialPay;
    }

    // helper method for calculating the bonus pays
    private static int calcBonusPay(int totalBonusHours, int totalWeekHours)
    {
        if (totalWeekHours > WEEKLY_MAX_HOURS)
        {
            return Math.abs((WEEKLY_MAX_HOURS - totalWeekHours) * 4) + (totalBonusHours * 2);
        }
        return (totalBonusHours * 2);
    }


}
