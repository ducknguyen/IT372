# string-sorter

## Documentation
#### IntelliJ did not recognize the java files:
*	Set up project SDK to 1.8
*	Set project language level from 9 to 8
*	Create a source directory, mark the directory as “Root Sources”, move all files into directory
*	Java files recognized by InteliJ

#### Classes won’t compile and showing error
*	InteliJ throws error “output path is not specified” 
*	Specify project compiler output file in project structure according to StackOverflow
*	Main classes compiled∂

#### InteliJ throws error because of JUnit
*	Move test related classes to new “test” package
*	Marked package as “Test Sources Root” 
*	Import jUnit from Maven (Junit 4.12)
*	Set findIdxBiggest and swap methods of StringSorter to public 

Main classes and test classes now compile with no errors.
